import { PrismaClient, Prisma } from "@prisma/client";
import { PrismaMariaDb } from "@prisma/adapter-mariadb";

declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

function createPrismaClient(): PrismaClient {
  // Next.js loads .env automatically before any API route runs.
  // We log here so we can confirm env is loaded at creation time.
  console.log("[prisma] connecting →", {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    database: process.env.DB_NAME,
    hasPassword: !!process.env.DB_PASSWORD,
  });

  const adapter = new PrismaMariaDb({
    host:            process.env.DB_HOST     || "localhost",
    port:            Number(process.env.DB_PORT) || 3306,
    user:            process.env.DB_USER     || "root",
    password:        process.env.DB_PASSWORD ?? "",
    database:        process.env.DB_NAME     || "wexa_ai",
    connectionLimit: 10,
  });

  return new PrismaClient({ adapter });
}

// In Next.js dev, module-level code runs before env is loaded on the
// very first import. Using a getter ensures the client is only created
// when first *used* (inside an API route), by which time Next.js has
// already injected all .env variables.
function getPrisma(): PrismaClient {
  if (!global.__prisma) {
    global.__prisma = createPrismaClient();
  }
  return global.__prisma;
}

export const prisma = new Proxy({} as PrismaClient, {
  get(_target, prop) {
    return (getPrisma() as unknown as Record<string | symbol, unknown>)[prop];
  },
});

export { Prisma };
